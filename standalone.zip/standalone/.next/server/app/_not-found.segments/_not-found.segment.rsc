1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js"],"default"]
3:I[37457,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"A-eVvc3zk6-BCx3I_m63n"}
