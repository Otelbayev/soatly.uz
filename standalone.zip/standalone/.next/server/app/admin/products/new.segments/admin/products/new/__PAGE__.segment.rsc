1:"$Sreact.fragment"
2:I[60655,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js","/_next/static/chunks/0nfm6ubzbosgn.js","/_next/static/chunks/126~0f59w8f5p.js"],"default"]
3:I[97367,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/126~0f59w8f5p.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"A-eVvc3zk6-BCx3I_m63n"}
5:null
