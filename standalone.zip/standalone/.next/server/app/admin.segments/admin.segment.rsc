1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js"],"ClientSegmentRoot"]
3:I[8374,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js","/_next/static/chunks/0nfm6ubzbosgn.js"],"default"]
4:I[39756,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js"],"default"]
5:I[37457,["/_next/static/chunks/02kahozdvq.-1.js","/_next/static/chunks/037a_ur8dl5i9.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/00ixw1f.awfcd.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/0nfm6ubzbosgn.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"A-eVvc3zk6-BCx3I_m63n"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
