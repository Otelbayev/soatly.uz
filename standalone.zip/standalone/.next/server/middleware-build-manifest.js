globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/A-eVvc3zk6-BCx3I_m63n/_buildManifest.js",
    "static/A-eVvc3zk6-BCx3I_m63n/_ssgManifest.js",
    "static/A-eVvc3zk6-BCx3I_m63n/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/0res8x7jei6tz.js",
    "static/chunks/0n1bpogj.il~n.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-06m6t_-~v3mbg.js"
  ]
};
