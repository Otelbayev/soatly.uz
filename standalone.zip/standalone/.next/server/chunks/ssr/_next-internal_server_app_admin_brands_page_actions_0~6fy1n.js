module.exports=[67499,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_brands_page_actions_0~6fy1n.js.map